﻿using Autodesk.AutoCAD.Runtime;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5_Complete_Cs
{
    public class PluginExtension : IExtensionApplication
    {
        public void Initialize()
        {
            // Add your initialization code here
        }

        public void Terminate()
        {
            // Add your termination code here
        }
    }
}
